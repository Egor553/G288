import express from "express";
import { PrismaClient } from "@prisma/client";
import { put } from "@vercel/blob";
import dotenv from "dotenv";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import nodemailer from "nodemailer";

dotenv.config();

const prisma = new PrismaClient();
const app = express();

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

app.post("/api/upload", async (req, res) => {
    try {
        const { filename, contentType, data } = req.body;
        if (!data) return res.status(400).json({ error: "No data" });

        // Если пришел base64 (старый формат), конвертируем в Buffer
        const buffer = data.startsWith("data:") 
            ? Buffer.from(data.split(",")[1], 'base64') 
            : Buffer.from(data, 'base64');

        const blob = await put(filename || 'upload.jpg', buffer, {
            contentType: contentType || 'image/jpeg',
            access: 'public',
        });

        res.json(blob);
    } catch (err: any) {
        console.error("Upload error:", err);
        res.status(500).json({ error: err.message });
    }
});

const JWT_SECRET = (process.env.JWT_SECRET || "fallback_secret").trim();
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN?.trim();
const APP_URL = process.env.APP_URL?.trim();

(BigInt.prototype as any).toJSON = function () {
    return this.toString();
};

const validateTelegramInitData = (initData: string): boolean => {
    if (!BOT_TOKEN) return false;
    try {
        const urlParams = new URLSearchParams(initData);
        const hash = urlParams.get("hash");
        urlParams.delete("hash");
        const dataCheckString = Array.from(urlParams.entries()).map(([k, v]) => `${k}=${v}`).sort().join("\n");
        const secretKey = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
        const calculatedHash = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");
        return calculatedHash === hash;
    } catch (err) { return false; }
};

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_PASS,
    },
});

const sendEmail = async (to: string, code: string) => {
    try {
        await transporter.sendMail({
            from: `"🐕 Со мной" <${process.env.GMAIL_USER}>`,
            to,
            subject: `${code} — ваш код для входа в Со мной`,
            html: `
                <div style="font-family: sans-serif; text-align: center; padding: 40px; background: #fff;">
                    <h1 style="color: #C47A84; font-size: 24px;">Привет! 🐾</h1>
                    <p style="color: #666; font-size: 16px;">Ваш код для входа или регистрации в приложении:</p>
                    <div style="font-size: 48px; font-weight: 900; color: #E8A0A8; letter-spacing: 15px; margin: 30px 0;">
                        ${code}
                    </div>
                    <p style="color: #999; font-size: 12px; margin-top: 40px;">Код действителен 10 минут.<br>Если вы не запрашивали этот код, просто проигнорируйте письмо.</p>
                </div>
            `,
        });
    } catch (err) {
        console.error("Email Error:", err);
    }
};

const sendTelegramNotification = async (chatId: string | bigint, text: string, buttons?: any) => {
    if (!BOT_TOKEN) return;
    try {
        await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ chat_id: String(chatId), text, reply_markup: buttons ? { inline_keyboard: buttons } : undefined })
        });
    } catch (err) { console.error("TG Notify Error", err); }
};

const handleTelegramUpdate = async (update: any) => {
    const msg = update.message;
    const cb = update.callback_query;
    if (msg && msg.text) {
        const chatId = BigInt(msg.chat.id);
        const text = msg.text;
        if (text.startsWith("/start")) {
            let user = await prisma.user.findUnique({ where: { telegramId: chatId } });
            if (!user) {
                user = await prisma.user.create({
                    data: {
                        telegramId: chatId,
                        firstName: msg.from.first_name || "User",
                        username: msg.from.username || "",
                        role: "CLIENT"
                    }
                });
            }
            const token = jwt.sign({ userId: user.id }, JWT_SECRET);
            const appUrl = process.env.APP_URL || "https://doggyservice-app.vercel.app";
            const loginUrl = `${appUrl}/?token=${token}`;

            await sendTelegramNotification(chatId, `👋 Привет, ${user.firstName}!\n\nНажми кнопку ниже, чтобы войти в аккаунт через браузер:`, [
                [{ text: "🚀 Войти на сайт", url: loginUrl }]
            ]);
        }
    }
    if (cb) {
        const adminId = process.env.ADMIN_TELEGRAM_ID;
        if (String(cb.from.id) === adminId) {
            const [action, userId] = cb.data.split(":");
            if (action === "approve") {
                await prisma.user.update({ where: { id: userId }, data: { role: "SPECIALIST" } });
                await prisma.specialistProfile.update({ where: { userId }, data: { status: "APPROVED" } });
                const u = await prisma.user.findUnique({ where: { id: userId } });
                if (u?.telegramId) await sendTelegramNotification(u.telegramId, "🎉 Ваша заявка одобрена! Теперь вы можете создавать свои услуги в разделе профиля.");
            }
            if (action === "reject") {
                await prisma.specialistProfile.update({ where: { userId }, data: { status: "REJECTED" } });
                const u = await prisma.user.findUnique({ where: { id: userId } });
                if (u?.telegramId) await sendTelegramNotification(u.telegramId, "❌ К сожалению, ваша заявка на специалиста отклонена. Проверьте данные и попробуйте позже.");
            }
        }
    }
};

const authMiddleware = async (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    const tgIdRaw = req.headers["x-telegram-id"];
    const initData = req.headers["x-telegram-init-data"];

    // 1. JWT Auth
    if (authHeader?.startsWith("Bearer ")) {
        try {
            const decoded = jwt.verify(authHeader.split(" ")[1], JWT_SECRET) as { userId: string };
            const user = await prisma.user.findUnique({ where: { id: decoded.userId }, include: { profile: true } });
            if (user) { req.user = user; return next(); }
        } catch (e) { }
    }

    // 2. Telegram Silent Auth
    if (tgIdRaw && tgIdRaw !== "undefined") {
        try {
            const tgId = BigInt(tgIdRaw);
            // Валидация данных только в продакшене
            if (process.env.NODE_ENV === "production" && initData) {
                const isValid = validateTelegramInitData(initData as string);
                if (!isValid) {
                    console.warn(`[Auth] Invalid TG data for ID: ${tgId}`);
                }
            }

            let user = await prisma.user.findUnique({ where: { telegramId: tgId }, include: { profile: true } });
            if (!user) {
                user = await prisma.user.create({
                    data: { telegramId: tgId, firstName: "User", role: "CLIENT" },
                    include: { profile: true }
                });
                console.log(`[Auth] Created auto-user for TG: ${tgId}`);
            }

            req.user = user;
            res.setHeader("x-new-token", jwt.sign({ userId: user.id }, JWT_SECRET));
        } catch (e) {
            console.error("[Auth] TG Auth Error:", e);
        }
    }

    if (!req.user) {
        console.warn(`[Auth] No user found for ${req.path}. TG ID: ${tgIdRaw}`);
    }

    next();
};

app.post("/api/webhook", async (req, res) => { await handleTelegramUpdate(req.body); res.status(200).send("OK"); });
app.get("/api/setup-webhook", async (req, res) => {
    const effectiveAppUrl = APP_URL || `https://${req.headers.host}`;
    const webhookUrl = `${effectiveAppUrl}/api/webhook`.replace(/\s/g, '');
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook?url=${webhookUrl}`);
    res.json({ success: true, url: webhookUrl, bot: BOT_TOKEN?.substring(0, 5) + "..." });
});

// --- AUTH ENDPOINTS ---

app.post("/api/auth/telegram-widget", async (req, res) => {
    const data = req.body;
    const { hash, ...checkData } = data;
    if (!BOT_TOKEN) return res.status(500).json({ error: "Bot token not configured" });

    const dataCheckString = Object.entries(checkData).map(([k, v]) => `${k}=${v}`).sort().join("\n");
    const secretKey = crypto.createHash("sha256").update(BOT_TOKEN).digest();
    const calculatedHash = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");

    if (calculatedHash !== hash) return res.status(401).json({ error: "Invalid hash" });

    try {
        const tgId = BigInt(data.id);
        let user = await prisma.user.findUnique({ where: { telegramId: tgId }, include: { profile: true } });
        if (!user) user = await prisma.user.create({ data: { telegramId: tgId, firstName: data.first_name || "User", username: data.username || "", role: "CLIENT" }, include: { profile: true } });
        const token = jwt.sign({ userId: user.id }, JWT_SECRET);
        res.json({ token, user });
    } catch (err: any) { res.status(500).json({ error: err.message }); }
});

app.post("/api/auth/send-otp", async (req, res) => {
    const { email, type } = req.body; // type: 'register', 'login', 'reset'
    try {
        const code = Math.floor(1000 + Math.random() * 9000).toString();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

        await (prisma as any).otpCode.deleteMany({ where: { email } });
        await (prisma as any).otpCode.create({ data: { email, code, expiresAt } });

        console.log(`[OTP] Created ${code} for ${email} (Type: ${type || 'auth'})`);

        if (process.env.GMAIL_USER && process.env.GMAIL_PASS) {
            await sendEmail(email, code);
        }

        res.json({ success: true, message: "Code sent" });
    } catch (err: any) { res.status(500).json({ error: err.message }); }
});

app.post("/api/auth/register", async (req, res) => {
    const { email, password, firstName, role, code } = req.body;
    try {
        const otpRecord = await (prisma as any).otpCode.findFirst({
            where: { email, code, expiresAt: { gt: new Date() }, used: false }
        });
        if (!otpRecord) return res.status(400).json({ error: "Неверный или истекший код" });

        const existingUser = await prisma.user.findUnique({ where: { email } });
        if (existingUser) return res.status(400).json({ error: "Пользователь с такой почтой уже существует" });

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await prisma.user.create({
            data: {
                email,
                password: hashedPassword,
                firstName,
                role: role || "CLIENT"
            },
            include: { profile: true }
        });

        await (prisma as any).otpCode.update({ where: { id: otpRecord.id }, data: { used: true } });

        const token = jwt.sign({ userId: user.id }, JWT_SECRET);
        res.json({ token, user });
    } catch (err: any) { res.status(500).json({ error: err.message }); }
});

app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await prisma.user.findUnique({ where: { email }, include: { profile: true } });
        if (!user || !user.password) return res.status(400).json({ error: "Пользователь не найден или пароль не установлен" });

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ error: "Неверный пароль" });

        const token = jwt.sign({ userId: user.id }, JWT_SECRET);
        res.json({ token, user });
    } catch (err: any) { res.status(500).json({ error: err.message }); }
});

app.post("/api/auth/reset-password", async (req, res) => {
    const { email, code, newPassword } = req.body;
    try {
        const otpRecord = await (prisma as any).otpCode.findFirst({
            where: { email, code, expiresAt: { gt: new Date() }, used: false }
        });
        if (!otpRecord) return res.status(400).json({ error: "Неверный или истекший код" });

        const hashedPassword = await bcrypt.hash(newPassword, 10);
        const user = await prisma.user.update({
            where: { email },
            data: { password: hashedPassword }
        });

        await (prisma as any).otpCode.update({ where: { id: otpRecord.id }, data: { used: true } });

        const token = jwt.sign({ userId: user.id }, JWT_SECRET);
        res.json({ token, user, success: true });
    } catch (err: any) { res.status(500).json({ error: err.message }); }
});

app.get("/api/me", authMiddleware, async (req: any, res) => {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const orderCount = await prisma.booking.count({ where: req.user.role === "CLIENT" ? { clientId: req.user.id } : { specialistId: req.user.profile?.id } });
    
    // Подгружаем полные данные профиля для редактирования
    let fullProfile = null;
    if (req.user.role === "SPECIALIST" && req.user.profile) {
        fullProfile = await prisma.specialistProfile.findUnique({
            where: { id: req.user.profile.id },
            include: { diplomas: true }
        });
    }

    const earnings = 0;
    res.json({ ...req.user, orderCount, earnings, profile: fullProfile || req.user.profile });
});

app.patch("/api/specialist/profile", authMiddleware, async (req: any, res) => {
    if (req.user.role !== "SPECIALIST" || !req.user.profile) {
        return res.status(403).json({ error: "Only specialists can update their profile" });
    }

    const { city, aboutText, favoriteTags, otherTags, priorityMetro, sitterExperience } = req.body;

    const updated = await prisma.specialistProfile.update({
        where: { id: req.user.profile.id },
        data: {
            city: city !== undefined ? city : undefined,
            aboutText: aboutText !== undefined ? aboutText : undefined,
            favoriteTags: favoriteTags !== undefined ? favoriteTags : undefined,
            otherTags: otherTags !== undefined ? otherTags : undefined,
            priorityMetro: priorityMetro !== undefined ? priorityMetro : undefined,
            sitterExperience: sitterExperience !== undefined ? String(sitterExperience) : undefined,
        }
    });

    res.json(updated);
});

// Специальный вход для админа
app.post("/api/auth/admin", async (req, res) => {
    const { email, password } = req.body;
    if (email === "admin" && password === "admin123") {
        let admin = await prisma.user.findFirst({ where: { role: "ADMIN" } });
        if (!admin) {
            admin = await prisma.user.create({
                data: {
                    email: "admin@system.local",
                    password: await bcrypt.hash("admin123", 10),
                    role: "ADMIN",
                    firstName: "Администратор"
                }
            });
        }
        const token = jwt.sign({ id: admin.id, role: "ADMIN" }, JWT_SECRET);
        return res.json({ token, user: admin });
    }
    res.status(401).json({ error: "Invalid admin credentials" });
});

app.post("/api/admin/specialists/:id/approve", authMiddleware, async (req: any, res) => {
    if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Access denied" });
    const { id } = req.params;

    const updated = await prisma.specialistProfile.update({
        where: { id },
        data: { status: "APPROVED" }
    });

    // Можно добавить уведомление в Telegram специалисту здесь
    res.json(updated);
});

app.post("/api/admin/specialists/:id/reject", authMiddleware, async (req: any, res) => {
    if (req.user.role !== "ADMIN") return res.status(403).json({ error: "Access denied" });
    const { id } = req.params;
    const { reason } = req.body;

    const updated = await prisma.specialistProfile.update({
        where: { id },
        data: {
            status: "REJECTED",
            rejectionReason: reason || "Не соответствует критериям"
        }
    });

    res.json(updated);
});

app.patch("/api/me", authMiddleware, async (req: any, res) => {
    if (!req.user) return res.status(401).json({ error: "Unauthorized" });
    const { name, phone, city, bio } = req.body;
    try {
        const updateData: any = {};
        if (name !== undefined) updateData.firstName = name;

        const profileData: any = {};
        if (city !== undefined) profileData.city = city;
        if (bio !== undefined) profileData.aboutText = bio;

        const updatedUser = await prisma.user.update({
            where: { id: req.user.id },
            data: {
                ...updateData,
                ...(Object.keys(profileData).length > 0 && req.user.role === "SPECIALIST" ? {
                    profile: { update: profileData }
                } : {})
            },
            include: { profile: true }
        });
        res.json(updatedUser);
    } catch (err: any) { res.status(500).json({ error: err.message }); }
});

app.get("/api/specialists", async (req, res) => {
    const { category } = req.query;
    const services = await prisma.service.findMany({
        where: category ? { category: category as string } : {},
        include: { profile: { include: { user: true, diplomas: true, bookings: { include: { review: true } } } } }
    });
    res.json(services.map(s => ({
        ...s, specialistId: s.profileId, specialist: {
            id: s.profileId, 
            userId: s.profile.userId,
            name: s.profile.user.firstName, 
            role: s.category === "SITTER" ? "Ситтер" : "Кинолог",
            rating: s.profile.rating || 5.0, 
            bio: s.profile.aboutText, 
            experience: s.profile.sitterExperience, 
            orders: s.profile.bookings.length,
            diplomas: s.profile.diplomas, 
            reviews: s.profile.bookings.filter(b => b.review).map(b => b.review)
        }
    })));
});

app.post("/api/specialist/register", authMiddleware, async (req: any, res) => {
    if (!req.user) return res.status(401).json({ error: "Необходима авторизация" });
    const { firstName, email, city, experience, about, diplomas } = req.body;
    try {
        const profile = await prisma.specialistProfile.upsert({
            where: { userId: req.user.id },
            create: { userId: req.user.id, aboutText: about, city, sitterExperience: String(experience), status: "PENDING", diplomas: { create: (diplomas || []).map((d: any) => ({ photoUrl: d.url, description: d.name })) } },
            update: { aboutText: about, city, sitterExperience: String(experience), status: "PENDING", diplomas: { deleteMany: {}, create: (diplomas || []).map((d: any) => ({ photoUrl: d.url, description: d.name })) } }
        });

        const adminId = process.env.ADMIN_TELEGRAM_ID;
        if (adminId) {
            try {
                // Отправляем текстовое сообщение с кнопками
                await sendTelegramNotification(adminId, `🔔 Новая заявка на специалиста!\n\n👤 Имя: ${firstName}\n📍 Город: ${city}\n📧 Email: ${email}\n⏳ Опыт: ${experience} лет\n📝 О себе: ${about}`, [
                    [
                        { text: "✅ Одобрить", callback_data: `approve:${req.user.id}` },
                        { text: "❌ Отклонить", callback_data: `reject:${req.user.id}` }
                    ]
                ]);

                // Если есть фото, отправляем их отдельно
                if (diplomas && diplomas.length > 0) {
                    for (const d of diplomas) {
                        try {
                            // Если это base64, конвертируем в Buffer для отправки
                            if (d.url.startsWith("data:image")) {
                                const base64Data = d.url.split(",")[1];
                                const buffer = Buffer.from(base64Data, 'base64');
                                
                                const formData = new (await import('form-data')).default();
                                formData.append('chat_id', adminId);
                                formData.append('photo', buffer, { filename: d.name });
                                formData.append('caption', `Документ: ${d.name} (${firstName})`);

                                await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendPhoto`, {
                                    method: 'POST',
                                    body: formData as any,
                                    headers: formData.getHeaders()
                                });
                            }
                        } catch (photoErr) {
                            console.error("Failed to send diploma photo:", photoErr);
                        }
                    }
                }
                console.log(`[Admin] Full notification sent to ${adminId}`);
            } catch (notifyErr) {
                console.error("[Admin] Failed to send notification:", notifyErr);
            }
        }

        res.json({ success: true });
    } catch (err: any) {
        console.error("Register Error:", err);
        res.status(500).json({ error: "Ошибка при сохранении анкеты" });
    }
});

app.get("/api/pets", authMiddleware, async (req: any, res) => { res.json(await prisma.dog.findMany({ where: { ownerId: req.user.id } })); });
app.post("/api/pets", authMiddleware, async (req: any, res) => {
    const { name, breed, ageYears, ageMonths, photoUrl } = req.body;
    res.json(await prisma.dog.create({ data: { name, breed, ageType: ageYears > 0 ? "YEARS" : "MONTHS", ageValue: Number(ageYears) || Number(ageMonths) || 1, ownerId: req.user.id, photoUrl } }));
});
app.patch("/api/pets/:id", authMiddleware, async (req: any, res) => {
    const { name, breed, ageYears, ageMonths, photoUrl } = req.body;
    const dog = await prisma.dog.findUnique({ where: { id: req.params.id } });
    if (!dog || dog.ownerId !== req.user.id) return res.status(403).json({ error: "Forbidden" });
    res.json(await prisma.dog.update({ where: { id: req.params.id }, data: { name, breed, ageType: ageYears > 0 ? "YEARS" : "MONTHS", ageValue: Number(ageYears) || Number(ageMonths) || 1, photoUrl } }));
});

// --- SERVICES ---
app.get("/api/services/me", authMiddleware, async (req: any, res) => {
    if (req.user.role !== "SPECIALIST" || !req.user.profile) return res.json([]);
    res.json(await prisma.service.findMany({ where: { profileId: req.user.profile.id } }));
});
app.post("/api/services", authMiddleware, async (req: any, res) => {
    if (req.user.role !== "SPECIALIST" || !req.user.profile) return res.status(403).json({ error: "Only specialists can add services" });
    const { name, price, duration, description, category, isOnline, id } = req.body;
    if (id) {
        res.json(await prisma.service.update({ where: { id, profileId: req.user.profile.id }, data: { name, price: Number(price), duration, description, category, isOnline } }));
    } else {
        res.json(await prisma.service.create({ data: { profileId: req.user.profile.id, name, price: Number(price), duration, description, category, isOnline } }));
    }
});
app.delete("/api/services/:id", authMiddleware, async (req: any, res) => {
    if (req.user.role !== "SPECIALIST" || !req.user.profile) return res.status(403).json({ error: "Forbidden" });
    await prisma.service.delete({ where: { id: req.params.id, profileId: req.user.profile.id } });
    res.json({ success: true });
});

// --- BOOKINGS ---
app.post("/api/bookings", authMiddleware, async (req: any, res) => {
    const { specialistId, serviceId, startDate, notes } = req.body;
    try {
        const specProfile = await prisma.specialistProfile.findUnique({ where: { id: specialistId }, include: { user: true } });
        if (!specProfile) return res.status(404).json({ error: "Specialist not found" });

        const booking = await prisma.booking.create({
            data: {
                specialistId,
                clientId: req.user.id,
                startDate: new Date(startDate),
                notes,
                status: "PENDING"
            }
        });

        if (specProfile.user.telegramId) {
            await sendTelegramNotification(specProfile.user.telegramId, `📅 Новая заявка!\nКлиент: ${req.user.firstName}\nКомментарий: ${notes}`, [[{ text: "Посмотреть заявки", url: `${process.env.APP_URL}/?tab=stats` }]]);
        }
        res.json(booking);
    } catch (err: any) { res.status(500).json({ error: err.message }); }
});

app.post("/api/bookings/:id/review", authMiddleware, async (req: any, res) => {
    const { score, text } = req.body;
    try {
        const booking = await prisma.booking.findUnique({ where: { id: req.params.id }, include: { specialist: true } });
        if (!booking || booking.clientId !== req.user.id) return res.status(403).json({ error: "Forbidden" });
        if (booking.status !== "COMPLETED") return res.status(400).json({ error: "Only completed bookings can be reviewed" });

        const review = await prisma.review.create({
            data: {
                bookingId: booking.id,
                score: Number(score),
                text,
                isInternal: false
            }
        });

        // Update avg rating
        const allReviews = await prisma.review.findMany({ where: { booking: { specialistId: booking.specialistId } } });
        const avg = allReviews.reduce((a: any, b: any) => a + b.score, 0) / allReviews.length;
        await prisma.specialistProfile.update({ where: { id: booking.specialistId }, data: { rating: avg } });

        res.json(review);
    } catch (err: any) { res.status(500).json({ error: err.message }); }
});

app.get("/api/messages", authMiddleware, async (req: any, res) => {
    res.json(await prisma.message.findMany({ where: { OR: [{ senderId: req.user.id }, { recipientId: req.user.id }] }, include: { sender: true, recipient: true }, orderBy: { createdAt: "asc" } }));
});
app.post("/api/messages", authMiddleware, async (req: any, res) => {
    const { text, recipientId } = req.body;
    const msg = await prisma.message.create({ data: { text, senderId: req.user.id, recipientId }, include: { sender: true } });
    if (recipientId) {
        const r = await prisma.user.findUnique({ where: { id: recipientId } });
        if (r?.telegramId) await sendTelegramNotification(r.telegramId, `✉️ Новое сообщение: ${text}`, [[{ text: "💬 Чат", url: `${process.env.APP_URL}/?tab=chats` }]]);
    }
    res.json(msg);
});

export default app;
